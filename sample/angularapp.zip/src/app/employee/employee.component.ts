import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.scss']
})
export class EmployeeComponent implements OnInit {

  constructor() { }

  employeeName:string='abc';
  imageurl:string="assets/image/angular.jpg";

  employees:any[]=[{employeeName:'Zach',exp:'2'},{employeeName:'pooja',exp:'3'},{employeeName:'Don',exp:'4'}];

  ngOnInit(): void {
  }


  btnClick()
  {
    this.employeeName="efgh";
  }
}
